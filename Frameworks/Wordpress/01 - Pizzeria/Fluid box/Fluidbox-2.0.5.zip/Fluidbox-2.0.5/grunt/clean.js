module.exports = {
    all: [
        "dist/"
    ]
};