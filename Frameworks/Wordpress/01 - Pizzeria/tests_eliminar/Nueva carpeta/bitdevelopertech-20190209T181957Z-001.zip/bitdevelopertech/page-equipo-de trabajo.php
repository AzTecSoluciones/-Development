<?php 

/*
* Template name: Trabajadores
*/   
get_header();?> 


    <?php while(have_posts()): the_post(); ?>


        <div class="hero" style = "background-image:url(<?php echo get_the_post_thumbnail_url() ?>);">
            <div class="contenido-hero">
                <div class="texto-hero">

                <h1><?php the_title(); ?></h1>

                </div>
            </div>
        
        </div>

        
        

    <div class="principal contenedor">
        <main class="texto-centrado contenido-paginas">
            <?php the_content(); ?>
        </main>
    </div>

    <?php endwhile; ?>

    <!-- Consulta -->
    <div class="nuestras-especialidades contenedor">
    <h3>Directivos</h3>
    <div class="contenedor-grid">

                <?php
                    $args = array(
                            'post_type' => 'equipotrabajo',
                            'post_per_page' => -1,
                            'orderby' => 'title',
                            'order' => ' ASC',
                            'category_name' => 'directivo'
                    );

                    $directivo = new WP_Query($args);
                    while($directivo->have_posts()): $directivo->the_post();
                ?>

                <div class = "">
                    <?php the_post_thumbnail(); ?>

                        <div class="texto-trabajador">
                            <h4> <?php the_title();?>  <span><?php  the_field('area'); ?></span></h4>
                            <?php the_content();?>
                        </div>
                </div>



                <?php endwhile;  wp_reset_postdata();?>
    </div>
    
    </div>




<?php get_footer();?>