<?php get_header();?>
    <h1>Hola desde single.php</h1>
<?php get_footer();?>
