<?php 

	echo "desde index.php";
?>